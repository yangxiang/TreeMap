1. The datasets in the folder "HighwayCentric" are used in the work "A Highway-Centric Labeling Approach for Answering Distance Queries on Large Sparse Graphs", Ruoming Jin, Ning Ruan, Yang Xiang, Victor Lee, SIGMOD 2012, pp 445-456.

2. The datasets in the folder "TEDI" are used in the work "Tedi: efficient shortest path query answering on graphs", Fang Wei, SIGMOD Conference, pp. 99�C110 (2010). These datasets are included in this program archive under the permission of Dr. Fang Wei.
